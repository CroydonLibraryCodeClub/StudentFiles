#!/bin/python3

print('hello')